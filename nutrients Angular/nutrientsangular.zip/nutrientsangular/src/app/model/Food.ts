import { Nutrient } from "./Nutrient";

export class Food {
    fdcId: Number | undefined;
    description: string | undefined;
    brandOwner: string | undefined;

    foodNutrients: Nutrient[] | undefined;





}