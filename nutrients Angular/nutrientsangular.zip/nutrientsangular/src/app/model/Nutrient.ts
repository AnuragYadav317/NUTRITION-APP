export class Nutrient {
    number: string | undefined;
    name: string | undefined;
    amount: number | undefined;
    unitName: string | undefined;
    derivationCode: string | undefined;
    derivationDescription: string | undefined;

}